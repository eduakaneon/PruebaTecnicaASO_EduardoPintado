package com.bbva.uuaa.helloWorld.facade.v0.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class DataOut {
    private String id;
    private String nuip;
    private Details details;
}
