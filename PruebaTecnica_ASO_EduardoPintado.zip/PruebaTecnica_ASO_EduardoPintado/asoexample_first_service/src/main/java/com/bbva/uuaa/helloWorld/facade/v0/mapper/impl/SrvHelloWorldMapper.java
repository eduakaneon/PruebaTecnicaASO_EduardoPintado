package com.bbva.uuaa.helloWorld.facade.v0.mapper.impl;

import com.bbva.uuaa.helloWorld.facade.v0.dto.*;
import com.bbva.uuaa.helloWorld.facade.v0.mapper.ISrvHelloWorldMapper;
import org.springframework.stereotype.Component;

@Component(value = "srvHelloWorldMapper")
public class SrvHelloWorldMapper {



    }


