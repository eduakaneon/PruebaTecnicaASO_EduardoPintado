package com.bbva.uuaa.helloWorld.business.v0.dao.impl;

import com.bbva.uuaa.helloWorld.business.v0.dao.ISrvHelloWorldDAO;
import com.bbva.uuaa.helloWorld.business.v0.dto.*;
import org.springframework.stereotype.Component;

import java.util.Random;

@Component(value = "srvHelloWorldDAO")
public class SrvHelloWorldDAO implements ISrvHelloWorldDAO {




public BDataOut mapData(BData bData) {
    BDataOut bDataOut = new BDataOut();
    Random random = new Random();
    long numero = random.nextInt(999999999) + 1;
    bDataOut.setId(String.valueOf(numero));
    bDataOut.setNuip(bData.getNuip());

    BDetails bDetails = new BDetails();
    bDetails.setOfferType(bData.getDetails().getOfferType());

    BLimitAmount bLimitAmount = new BLimitAmount();
    bLimitAmount.setAmount(bData.getDetails().getLimitAmount().getAmount());
    bLimitAmount.setCurrency(bData.getDetails().getLimitAmount().getCurrency());
    bDetails.setLimitAmount(bLimitAmount);

    BMaximumAmount bMaximumAmount = new BMaximumAmount();
    bMaximumAmount.setAmount(bLimitAmount.getAmount() * 1.05);
    bMaximumAmount.setCurrency(bLimitAmount.getCurrency());
    bDetails.setMaximumAmount(bMaximumAmount);

    BMinimumAmount bMinimumAmount = new BMinimumAmount();
    bMinimumAmount.setAmount(bLimitAmount.getAmount() * 0.9);
    bMinimumAmount.setCurrency(bLimitAmount.getCurrency());
    bDetails.setMinimumAmount(bMinimumAmount);

    BProduct bProduct = new BProduct();
    bProduct.setId(bData.getDetails().getProduct().getId());

    BSubproduct bSubproduct = new BSubproduct();
    bSubproduct.setId(bData.getDetails().getProduct().getSubproduct().getId());
    bProduct.setSubproduct(bSubproduct);
    bDetails.setProduct(bProduct);
    bDataOut.setDetails(bDetails);
    return bDataOut;
}
}



