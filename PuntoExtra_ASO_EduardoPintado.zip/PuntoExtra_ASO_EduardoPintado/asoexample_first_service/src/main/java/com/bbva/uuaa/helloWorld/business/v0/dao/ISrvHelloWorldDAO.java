package com.bbva.uuaa.helloWorld.business.v0.dao;

import com.bbva.uuaa.helloWorld.business.v0.dto.*;

public interface ISrvHelloWorldDAO {

    BUserDataOut mapUser (BUserData bUserData);

}
