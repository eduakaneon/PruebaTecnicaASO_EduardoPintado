package com.bbva.uuaa.helloWorld.facade.v0.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class UserData {

    @NotNull(message = "El nombre no puede ser nulo")
    @NotBlank(message = "El nombre no puede estar vacío")
    @Pattern(regexp = "[A-Z_]+")
    private String nombre;

    @NotNull(message = "El apellido no puede ser nulo")
    @Pattern(regexp = "[A-Z_]+")
    private String apellido;


    private Number celular;


    @Email(message = "El correo debe ser válido")
    private String correo;

    @NotNull(message = "El DNI no puede ser nulo")
    @NotBlank(message = "El DNI no puede estar vacío")
    private String dni;

}
