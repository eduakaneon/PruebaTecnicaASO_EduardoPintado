package com.bbva.uuaa.helloWorld.facade.v0.dto;

import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

@Getter
@Setter
public class UserData {
    @NotBlank(message = "El nombre no puede estar vacío")
    private String nombre;

    private String apellido;

    @NotBlank(message = "El celular no puede estar vacío")
    @Pattern(regexp="\\d{10}", message = "El celular debe contener exactamente 10 dígitos")
    private String celular;

    @NotBlank(message = "El correo no puede estar vacío")
    @Email(message = "El correo debe ser válido")
    private String correo;

    @NotBlank(message = "El DNI no puede estar vacío")
    private String dni;

}
