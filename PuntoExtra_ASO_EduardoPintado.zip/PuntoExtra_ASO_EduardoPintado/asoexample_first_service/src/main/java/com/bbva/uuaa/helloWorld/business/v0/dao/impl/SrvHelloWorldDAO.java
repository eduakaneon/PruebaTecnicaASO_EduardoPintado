package com.bbva.uuaa.helloWorld.business.v0.dao.impl;

import com.bbva.uuaa.helloWorld.business.v0.dao.ISrvHelloWorldDAO;
import com.bbva.uuaa.helloWorld.business.v0.dto.*;
import org.springframework.stereotype.Component;

@Component(value = "srvHelloWorldDAO")
public class SrvHelloWorldDAO implements ISrvHelloWorldDAO {


    @Override
    public BUserDataOut mapUser(BUserData bUserData) {
        BUserDataOut bUserDataOut = new BUserDataOut();
        bUserDataOut.setApellido(bUserData.getApellido());
        bUserDataOut.setDni(bUserData.getDni());
        bUserDataOut.setNombre(bUserData.getNombre());
        bUserDataOut.setCorreo(bUserData.getCorreo());
        bUserDataOut.setCelular(bUserData.getCelular());

        return bUserDataOut;
    }


}
