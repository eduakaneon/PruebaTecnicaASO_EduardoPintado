package com.bbva.uuaa.helloWorld.business.v0.dao.impl;

import com.bbva.uuaa.helloWorld.business.v0.dao.ISrvHelloWorldDAO;
import com.bbva.uuaa.helloWorld.business.v0.dto.*;
import org.springframework.stereotype.Component;

@Component(value = "srvHelloWorldDAO")
public class SrvHelloWorldDAO implements ISrvHelloWorldDAO {


        @Override
        public BUserDataOut mapUser(BUserData bUserData) {
            BUserDataOut bUserDataOut = new BUserDataOut();

            if(validateObject(bUserData) || !isValidCelular(bUserData.getCelular()) ){
                return null;
            }
            bUserDataOut.setNombre(bUserData.getNombre());
            bUserDataOut.setApellido(bUserData.getApellido());
            bUserDataOut.setDni(bUserData.getDni());
            bUserDataOut.setCorreo(bUserData.getCorreo());
            bUserDataOut.setCelular(bUserData.getCelular());

            return bUserDataOut;
        }
        private boolean isValidCelular(Number celular) {
            if (celular == null) {
                return false;
            }
            String celularString = celular.toString();
            return celularString.length() == 10;
        }

        private boolean validateObject(BUserData bUserData){
            return bUserData == null ;
        }
    }


