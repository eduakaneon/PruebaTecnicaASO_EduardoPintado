package com.bbva.uuaa.helloWorld.business.v0;

import com.bbva.uuaa.helloWorld.business.v0.dto.*;

public interface IBSrvHelloWorld {

    BUserDataOut businessUser (BUserData bUserData);

}
