package com.bbva.uuaa.helloWorld.facade.v0.impl;

import com.bbva.jee.arq.spring.core.catalog.gabi.ServiceResponse;
import com.bbva.jee.arq.spring.core.catalog.gabi.ServiceResponseCreated;
import com.bbva.jee.arq.spring.core.catalog.gabi.ServiceResponseNoContent;
import com.bbva.jee.arq.spring.core.servicing.annotations.SMC;
import com.bbva.jee.arq.spring.core.servicing.annotations.SN;
import com.bbva.jee.arq.spring.core.servicing.annotations.VN;
import com.bbva.uuaa.helloWorld.business.v0.IBSrvHelloWorld;
import com.bbva.uuaa.helloWorld.business.v0.dto.*;
import com.bbva.uuaa.helloWorld.facade.v0.ISrvHelloWorld;
import com.bbva.uuaa.helloWorld.facade.v0.dto.*;
import com.bbva.uuaa.helloWorld.facade.v0.mapper.ISrvHelloWorldMapper;
import org.mapstruct.factory.Mappers;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import javax.validation.Valid;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

@Service
@SN(registryID = "SN000000001", logicalID = "helloWorld")
@VN(vnn = "v0")
@Path("/v0")
public class SrvHelloWorld implements ISrvHelloWorld {

    @Resource(name = "bSrvHelloWorld")
    private IBSrvHelloWorld business;









    @Override
    @POST
    @Path("/createUser")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @SMC(registryID = "SMC000000073", logicalID = "createUser")
    // @Valid para que valide el objeto y que sean validas las anotaciones estilo @NotNull
    public ServiceResponseCreated<UserDataOut> createUser(@Valid UserData userData){
        ISrvHelloWorldMapper map = Mappers.getMapper(ISrvHelloWorldMapper.class);
        BUserData bUserData = map.mapInUser(userData);
        BUserDataOut bUserDataOut = business.businessUser(bUserData);
        UserDataOut userDataOut = map.mapOutUser(bUserDataOut);
        return ServiceResponseCreated.data(userDataOut).build();
    }
    @Override
    @PUT
    @Path("/createUserPut")
    @Produces({MediaType.APPLICATION_JSON})
    @Consumes({MediaType.APPLICATION_JSON})
    @SMC(registryID = "SMC000000083", logicalID = "createUserPut")
    // @Valid para que valide el objeto y que sean validas las anotaciones estilo @NotNull
    public ServiceResponseNoContent createUserPut(@Valid UserData userData){
        ISrvHelloWorldMapper map = Mappers.getMapper(ISrvHelloWorldMapper.class);
        BUserData bUserData = map.mapInUser(userData);
//        BUserDataOut bUserDataOut = business.businessUser(bUserData);
//        UserDataOut userDataOut = map.mapOutUser(bUserDataOut);
        return ServiceResponseNoContent.ServiceResponseNoContentBuilder.build();
    }



}
